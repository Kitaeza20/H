﻿
    public static class ConnectionString
    {
    public static string GetPath = @"C:\Users\Пользователь\Desktop\l8\ЬЬЬ\ЬЬЬ\Database1.mdf";//Переменная, в которой хранится путь до базы данных

        public static string GetConectString()//Функция для получения строки подключения к БД
        {
            string ConnectionString = $@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""{GetPath}"";Integrated Security=True";//Формирование строки подключекния к Базе данных
            return ConnectionString;
        }
       
    }
