﻿using System.Collections.Generic;
    public static class SaveUserInfo
    {
        public static List<string> UserInformation { get; set; }
    }

