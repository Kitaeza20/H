﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ЬЬЬ
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        WorkWithDb G = new WorkWithDb();
        FillDataGridView S = new FillDataGridView();
        private string ThisTable {  get; set; }
        private void Form2_Load(object sender, EventArgs e)
        {
            List<string> AllTables = G.AllTableNameFromDB();
            new FillListBox(AllTables, listBox1);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            ThisTable = listBox1.SelectedItem.ToString();
            S.FillDatGridView(ThisTable, dataGridView1);
            List<string> colums = G.GetAllColumnName(ThisTable);
            new CreateListBox(panel1, colums);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            GetInputDataFromPanel.GetInputDataPanel(panel1);
            GenerateSqlQuery J = new GenerateSqlQuery();
            List<string> Result = GetInputDataFromPanel.Result;
            List<string> Count = GetInputDataFromPanel.ColumnName;

            if(radioButton1.Checked)
            {
                G.UserQuery(J.InsertQuery(Result, ThisTable));
            }
            else if(radioButton2.Checked)
            {
                G.UserQuery(J.UpdateQuery(Result, Count, ThisTable));
            }
            else if(radioButton3.Checked)
            {
                G.UserQuery(J.DeleteQuery(Result, Count, ThisTable));
            }

        }
    }
}
